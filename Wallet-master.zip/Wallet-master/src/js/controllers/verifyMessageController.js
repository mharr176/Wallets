'use strict';

angular.module('copayApp.controllers').controller('verifyMessageController', function($scope, $interval, profileService, walletService, popupService, lodash, $ionicNavBarDelegate, signVerifyMessageService) {
});
