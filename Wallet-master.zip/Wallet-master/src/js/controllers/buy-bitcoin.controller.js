'use strict';

(function() {
  angular
      .module('bitcoincom.controllers')
      .controller('buyBitcoinController', buyBitcoinController);

  function buyBitcoinController($scope) {

    $scope.focussedEl = false;

    var controller = {
      // Functions
    };
    return controller;
  }
})();
