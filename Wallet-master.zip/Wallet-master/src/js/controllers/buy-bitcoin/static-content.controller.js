'use strict';

(function() {
  angular
      .module('bitcoincom.controllers')
      .controller('buyBitcoinStaticContentController', staticContentController);

  function staticContentController($scope) {

    var controller = {
      // Functions
    };
    return controller;
  }
})();
