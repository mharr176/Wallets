window.TREZOR_CHROME_URL = './bower_components/trezor-connect/chrome/wrapper.html';

