'use strict';

angular.module('copayApp.services').factory('desktopSecureStorageService', function($log) {
  // Placeholder
  return {};
});